#ifndef MESSAGE_H_
#define MESSAGE_H_


struct message
{
	char info[1400];
};


#endif