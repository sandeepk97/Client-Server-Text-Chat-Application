#ifndef BLOCK_H_
#define BLOCK_H_

struct Block
{
	char IP[50];
	char port[50];
};

#endif